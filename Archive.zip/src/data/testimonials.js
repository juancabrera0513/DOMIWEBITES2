// src/data/testimonials.js
export const testimonials = [
    // Ejemplos — reemplaza por los tuyos anteriores
    { name: "John D.", role: "Owner, Local Plumbing", quote: "Professional team, smooth process, and our phone hasn’t stopped ringing." },
    { name: "Sarah M.", role: "Founder, Boutique", quote: "Clean design and faster pages. We noticed more inquiries within the first month." },
    // ...
  ];
  
  export default testimonials;
  