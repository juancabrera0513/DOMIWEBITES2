// src/pages/WorkPage.jsx
import React, { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { useTranslation } from "react-i18next";
import Header from "../components/Header";
import Footer from "../components/Footer";
import StickyCTA from "../components/StickyCTA";
import SeoJsonLd from "../components/SeoJsonLd";
import ProjectModal from "../components/ProjectModal";
import { PROJECTS, PORTFOLIO_CATEGORIES } from "../data/projects";

function CategoryPill({ active, children, onClick }) {
  return (
    <button
      onClick={onClick}
      className={[
        "px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all select-none",
        "border focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200/40",
        active
          ? "text-[#061019] border-white/10 bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400 shadow-[0_0_0_1px_rgba(255,255,255,.08),0_16px_45px_rgba(34,211,238,.18)] hover:-translate-y-[1px]"
          : "text-white/80 bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/15",
      ].join(" ")}
      aria-pressed={active}
      type="button"
    >
      {children}
    </button>
  );
}

function PremiumTag({ children }) {
  return (
    <span className="tag-premium group inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-[13px] text-white/75 ring-1 ring-white/10 bg-white/[0.035] shadow-[0_10px_30px_rgba(0,0,0,.25)] transition-transform duration-300 hover:-translate-y-[1px]">
      <span className="tag-dot h-1.5 w-1.5 rounded-full bg-cyan-300/90 shadow-[0_0_14px_rgba(34,211,238,.45)]" />
      <span className="tag-text">{children}</span>
      <span aria-hidden className="tag-shimmer pointer-events-none absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </span>
  );
}

const CATEGORIES = PORTFOLIO_CATEGORIES || ["All"];

export default function WorkPage() {
  const { t } = useTranslation(["meta", "portfolio"]);
  const [filter, setFilter] = useState("All");
  const [modal, setModal] = useState(null);

  const prefersReducedMotion =
    typeof window !== "undefined" &&
    window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") setModal(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const projects = useMemo(() => {
    if (filter === "All") return PROJECTS;
    return PROJECTS.filter((p) => p.category === filter);
  }, [filter]);

  const title =
    t("meta:work_title", "Our Work | Domi Websites") || "Our Work | Domi Websites";

  const description =
    t("meta:work_description", "Websites that convert and custom software that scales.") ||
    "Websites that convert and custom software that scales.";

  const heroTags = useMemo(
    () => ["Mobile-first", "Conversion-focused", "AI-enabled", "Chatbots", "Automation-ready", "Built to scale"],
    []
  );

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:type" content="website" />
      </Helmet>

      <SeoJsonLd />
      <Header />

      <main id="main-content" className="nexus-bg hero-grid relative overflow-hidden">
        <div className="hero-vignette" />

        <section className="section relative z-10">
          <div className="container">
            {/* HERO HEADER */}
            <div className="text-center max-w-4xl mx-auto">
              <p className="text-[11px] tracking-[0.25em] uppercase text-cyan-200/70 mb-3">
                {t("portfolio:label", "OUR WORK")}
              </p>

              <h1 className="font-extrabold tracking-tight leading-[1.05] text-center">
                <span className="block text-[40px] sm:text-[56px] md:text-[72px] lg:text-[88px] text-white">
                  {t("portfolio:work_h1_a", "Websites that convert.")}
                </span>

                <span className="block text-[48px] sm:text-[64px] md:text-[82px] lg:text-[98px] grad-text">
                  {t("portfolio:work_h1_b", "Custom software that scales.")}
                </span>
              </h1>

              <p className="mt-8 text-[15px] sm:text-lg text-white/60 max-w-3xl mx-auto leading-relaxed text-center">
                {t(
                  "portfolio:work_sub",
                  "We design high-performing websites and build custom software systems — including CRMs, automation platforms, AI-powered chatbots, and intelligent internal tools — engineered to streamline operations and drive scalable growth."
                )}
              </p>

              <div className="mt-8 flex flex-wrap justify-center gap-2.5">
                {heroTags.map((tag) => (
                  <span key={tag} className="relative">
                    <PremiumTag>{tag}</PremiumTag>
                  </span>
                ))}
              </div>

        
            </div>

            {/* FILTERS */}
            <div className="mt-14 flex flex-wrap justify-center gap-2">
              {CATEGORIES.map((c) => (
                <CategoryPill key={c} active={filter === c} onClick={() => setFilter(c)}>
                  {c === "All" ? t("portfolio:all", "All") : c}
                </CategoryPill>
              ))}
            </div>

            {/* GRID */}
            {projects.length ? (
              <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map((p, idx) => {
                  const key = p.i18nKey;
                  const projectTitle = key ? t(`portfolio:${key}.name`, p.title) : p.title;
                  const projectDesc = key ? t(`portfolio:${key}.short`, p.description) : p.description;

                  return (
                    <article
                      key={p.id}
                      className="group rounded-2xl overflow-hidden bg-white/5 border border-white/10 shadow-[0_10px_30px_rgba(0,0,0,.35)] hover:shadow-[0_30px_80px_rgba(0,0,0,.55)] transition-all hover:-translate-y-1"
                      style={
                        prefersReducedMotion
                          ? undefined
                          : { animationDelay: `${Math.min(idx * 40, 240)}ms` }
                      }
                    >
                      <button
                        onClick={() => setModal(p)}
                        className="text-left block w-full focus:outline-none"
                        type="button"
                        aria-haspopup="dialog"
                        aria-label={`Open details for ${projectTitle}`}
                      >
                        <div className="relative h-48 bg-black/40">
                          {p.image ? (
                            <img
                              src={p.image}
                              alt={`${projectTitle} preview`}
                              className="absolute inset-0 w-full h-full object-cover"
                              loading="lazy"
                              decoding="async"
                              onError={(e) => {
                                e.currentTarget.style.display = "none";
                              }}
                            />
                          ) : null}

                          <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-black/0" />
                          <div className="absolute inset-0 bg-white/0 group-hover:bg-white/5 transition-colors" />

                          {p.category ? (
                            <div className="absolute top-3 left-3">
                              <span className="inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold border border-white/10 bg-white/5 text-white/80">
                                {p.category}
                              </span>
                            </div>
                          ) : null}
                        </div>

                        <div className="p-5">
                          <h3 className="text-white/90 font-semibold text-lg">
                            {projectTitle}
                          </h3>

                          <p className="text-white/60 text-sm mt-2 leading-relaxed line-clamp-2">
                            {projectDesc}
                          </p>

                          {/* Optional mini tags (NOT like filters) */}
                          {(p.kpis?.length || p.tags?.length) ? (
                            <div className="mt-4 flex flex-wrap gap-2">
                              {(p.kpis || []).slice(0, 2).map((k) => (
                                <span
                                  key={k}
                                  className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] text-emerald-200 bg-emerald-500/10 border border-emerald-300/15"
                                >
                                  {k}
                                </span>
                              ))}

                              {(p.tags || []).slice(0, 2).map((tg) => (
                                <span
                                  key={tg}
                                  className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] text-white/65 bg-white/[0.035] border border-white/10"
                                >
                                  {tg}
                                </span>
                              ))}
                            </div>
                          ) : null}

                          <div className="mt-4 inline-flex items-center gap-2 text-cyan-200/90 text-sm font-medium group-hover:underline underline-offset-4">
                            {t("portfolio:view_details", "View details")}
                            <span aria-hidden>→</span>
                          </div>
                        </div>
                      </button>
                    </article>
                  );
                })}
              </div>
            ) : (
              <div className="mt-12 max-w-2xl mx-auto text-center glass rounded-2xl p-8 border border-white/10">
                <div className="text-white/85 font-semibold text-lg">No projects found</div>
                <p className="mt-2 text-white/55">
                  Try another filter, or switch back to <span className="text-white/75">All</span>.
                </p>
                <div className="mt-5 flex justify-center">
                  <button type="button" className="btn btn-outline" onClick={() => setFilter("All")}>
                    Reset filters
                  </button>
                </div>
              </div>
            )}
          </div>
        </section>

        <style>{`
          /* Premium tags shimmer + gradient edge (NOT like filter pills) */
          .tag-premium{
            position: relative;
            overflow: hidden;
          }
          .tag-premium::before{
            content:"";
            position:absolute;
            inset:0;
            border-radius:9999px;
            padding:1px;
            background: linear-gradient(90deg, rgba(34,211,238,.45), rgba(96,165,250,.35), rgba(167,139,250,.35));
            -webkit-mask:
              linear-gradient(#000 0 0) content-box,
              linear-gradient(#000 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            opacity: .35;
            pointer-events:none;
          }
          .tag-premium:hover::before{ opacity: .55; }

          .tag-premium .tag-shimmer{
            background: linear-gradient(120deg,
              transparent 0%,
              rgba(255,255,255,.10) 35%,
              rgba(255,255,255,.22) 50%,
              rgba(255,255,255,.10) 65%,
              transparent 100%);
            transform: translateX(-120%);
          }

          @media (prefers-reduced-motion: no-preference){
            .tag-premium:hover .tag-shimmer{
              animation: shimmerMove .9s ease-out forwards;
            }
          }

          @keyframes shimmerMove{
            to { transform: translateX(120%); }
          }

          @media (prefers-reduced-motion: reduce){
            .tag-premium:hover .tag-shimmer{ animation: none; }
          }
        `}</style>
      </main>

      <Footer />
      <StickyCTA />

      {modal && <ProjectModal project={modal} onClose={() => setModal(null)} />}
    </>
  );
}
