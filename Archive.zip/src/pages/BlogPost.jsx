import React, { useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "../components/Header";
import Footer from "../components/Footer";
import StickyCTA from "../components/StickyCTA";
import SeoJsonLd from "../components/SeoJsonLd";
import { blogPosts } from "../data/blogPosts";

function formatDate(dateStr) {
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
  } catch {
    return dateStr;
  }
}

export default function BlogPost() {
  const { slug } = useParams();

  const post = useMemo(() => blogPosts.find((p) => p.slug === slug), [slug]);

  const siteUrl = "https://domiwebsites.com";
  const blogIndexUrl = `${siteUrl}/blog`;

  if (!post) {
    const title = "Post Not Found | Domi Websites Blog";
    const description = "The requested blog post could not be found on Domi Websites.";

    return (
      <>
        <Helmet>
          <title>{title}</title>
          <meta name="description" content={description} />
          <link rel="canonical" href={blogIndexUrl} />
          <meta name="robots" content="noindex,follow" />
        </Helmet>

        <SeoJsonLd />
        <Header />

        <main id="main-content">
          <section className="section">
            <div className="container">
              <div className="max-w-2xl mx-auto text-center glass rounded-2xl p-8 border border-white/10">
                <h1 className="text-3xl md:text-4xl font-extrabold text-white">Post not found</h1>
                <p className="mt-3 text-white/60">
                  This URL doesn’t match any published post.
                </p>
                <div className="mt-6 flex justify-center gap-3 flex-wrap">
                  <Link to="/blog" className="btn btn-primary">
                    Back to Blog
                  </Link>
                  <Link to="/contact" className="btn btn-outline">
                    Contact
                  </Link>
                </div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
        <StickyCTA />
      </>
    );
  }

  const postUrl = `${siteUrl}/blog/${post.slug}`;
  const imageUrl = post.image ? `${siteUrl}${post.image}` : `${siteUrl}/DomiLogo.webp`;

  const title = `${post.title} | Domi Websites Blog`;
  const description = post.summary;

  const articleLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description,
    image: [imageUrl],
    author: { "@type": "Person", name: "Juan Cabrera" },
    publisher: {
      "@type": "Organization",
      name: "Domi Websites",
      logo: { "@type": "ImageObject", url: `${siteUrl}/DomiLogo.webp` },
    },
    datePublished: post.date,
    dateModified: post.date,
    mainEntityOfPage: { "@type": "WebPage", "@id": postUrl },
  };

  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: siteUrl },
      { "@type": "ListItem", position: 2, name: "Blog", item: blogIndexUrl },
      { "@type": "ListItem", position: 3, name: post.title, item: postUrl },
    ],
  };

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={postUrl} />

        <meta property="og:title" content={post.title} />
        <meta property="og:description" content={description} />
        <meta property="og:image" content={imageUrl} />
        <meta property="og:url" content={postUrl} />
        <meta property="og:type" content="article" />

        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={post.title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={imageUrl} />

        <script type="application/ld+json">{JSON.stringify(articleLd)}</script>
        <script type="application/ld+json">{JSON.stringify(breadcrumbLd)}</script>
      </Helmet>

      <SeoJsonLd />
      <Header />

      <main id="main-content">
        <section className="section">
          <div className="container">
            <div className="max-w-3xl mx-auto">
              <nav className="text-sm text-white/55 mb-6">
                <Link to="/" className="text-cyan-200/90 hover:underline underline-offset-4">
                  Home
                </Link>
                <span className="mx-2">/</span>
                <Link to="/blog" className="text-cyan-200/90 hover:underline underline-offset-4">
                  Blog
                </Link>
                <span className="mx-2">/</span>
                <span className="text-white/70">{post.title}</span>
              </nav>

              <header className="glass rounded-2xl border border-white/10 overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,.55)]">
                <div className="p-7 md:p-9">
                  <p className="text-[11px] tracking-[0.25em] uppercase text-cyan-200/70 mb-3">
                    ARTICLE
                  </p>

                  <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
                    {post.title}
                  </h1>

                  <p className="mt-3 text-white/55 text-sm">
                    {formatDate(post.date)} • By <span className="text-white/75 font-medium">Juan Cabrera</span>
                  </p>

                  <p className="mt-5 text-white/60 leading-relaxed">
                    {post.summary}
                  </p>
                </div>

                {post.image ? (
                  <div className="relative h-56 md:h-72 bg-black/40">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="absolute inset-0 w-full h-full object-cover"
                      loading="lazy"
                      decoding="async"
                      onError={(e) => {
                        e.currentTarget.style.display = "none";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/15 to-black/0" />
                  </div>
                ) : null}
              </header>

              <article className="mt-10 glass rounded-2xl border border-white/10 p-7 md:p-9">
                <div
                  className="prose prose-invert max-w-none prose-a:text-cyan-200/90 prose-a:underline prose-a:underline-offset-4 prose-strong:text-white"
                  dangerouslySetInnerHTML={{ __html: post.content }}
                />
              </article>

              <div className="mt-10 flex flex-wrap gap-3">
                <Link to="/blog" className="btn btn-outline">
                  ← Back to Blog
                </Link>
                <Link to="/contact" className="btn btn-primary">
                  Start a Project
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <StickyCTA />
    </>
  );
}
